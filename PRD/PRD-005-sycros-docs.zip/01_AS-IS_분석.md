# Sycros MM 플러그인 AS-IS 분석서

> 분석 대상: `mm-plugins-Sycros-main` (plugin id: `dmove-sycros`, v2.2.1, Go 1.24 / mattermost-plugin-starter-template 기반)
> 작성일: 2026-07-08 · 작성: 소스 정적 분석 기준 (Claude)

## 1. 핵심 요약

- **아키텍처는 Push(웹훅)가 아니라 Pull(DB 폴링)이다.** 플러그인이 Sycros DB 테이블을 주기 폴링(기본 30초)하여 신규 row를 감지하고 발송한다. 기존 PRD의 "알람 수신 시 payload의 hostname 조회" 서술은 실제 구조와 다르며, TO-BE 설계는 폴링 전제를 반영해야 한다.
- 독립된 **2개 파이프라인**이 존재한다: ① DM 파이프라인(`tb_kko_tran` 폴링 → 전화번호 → Crowd DB 사용자 매핑 → 개인 DM), ② 채널 파이프라인(`{prefix}_YYYYMMDD` 일별 테이블 폴링 → state 값 매칭 채널 발송).
- **채널 라우팅의 실체는 `state`(심각도 코드, 1~4) 정확 일치 매칭**이다. 이것이 "레벨 단위 채널 체계"의 구현체이며, 이번 개편에서 조직 단위(hostname/service_code) 라우팅으로 대체·확장할 대상이다.
- **HA 중복 방지는 이미 구현되어 있다.** 각 노드가 독립 폴링하되 `KVSetWithOptions{Atomic, TTL 300s}` 로 row 단위 선점 마킹(`tryMarkRowAsProcessed`)하는 방식.
- **관리 UI도 이미 존재한다.** System Console의 custom 설정(`notification_channels`)을 React 컴포넌트(`ChannelSettings.tsx`)로 편집하는 구조. 단, 설정 저장 시 `OnConfigurationChange → restartPolling`이 호출되어 **매핑 변경 = 폴링 전체 재시작**이라는 부작용이 있다.
- HTTP API(`api/api.go`)와 슬래시 커맨드(`/hello`)는 starter-template 스텁 상태로, **api 패키지는 plugin.go에 연결조차 되어 있지 않은 데드 코드**다. 웹훅 수신 인프라는 사실상 신규 개발이다.

## 2. 컴포넌트 맵

| 파일 | 역할 | 개편 시 판단 |
|---|---|---|
| `server/plugin.go` (1,390줄) | 폴링·라우팅·발송·포맷·KV 관리 전부 단일 파일 | 파이프라인 분리 리팩토링 대상 (핵심) |
| `server/configuration.go` | 설정 구조체, DB 연결 문자열, **Crowd DB 크레덴셜 하드코딩** | 크레덴셜 외부화 필수 (§5-1) |
| `server/command/command.go` | `/hello` 스텁 | 신규 커맨드로 교체 |
| `api/api.go` | gorilla/mux 라우터 스텁 — **미연결(데드 코드)** | Tmax 웹훅·관리 API의 골격으로 재활용 가능 |
| `webapp/src/components/ChannelSettings.tsx` | System Console 채널 설정 UI (253줄) | 매핑 관리 UI로 확장 또는 대체 (§5-8) |
| `server/store/kvstore/` | KV 래퍼 (스텁 수준) | 매핑 저장소로 확장 |

## 3. 데이터 흐름

### 3-1. 채널 알림 파이프라인 (본 개편의 주 대상)

```
channelPollingLoopWithLock (tick = PollInterval초)
  ├─ 날짜 변경 감지 → 오늘 테이블 max 위치로 리셋 (※ 결함 §5-4)
  ├─ checkForNewChannelRows: {ChannelTableName}_{YYYYMMDD} 에서
  │     event_id > lastPos 조건, event_id ASC, LIMIT 100
  │     └─ row별 getChannelRowData 개별 SELECT * (N+1, §5-6)
  ├─ row마다:
  │   ├─ tryMarkRowAsProcessed("channel", event_id, 300s)  ← HA 선점
  │   ├─ formatChannelMessage: host_name/host_alias/create_date/message 렌더
  │   └─ sendChannelNotification:
  │         state 추출 (state==0이면 발송 안 함, WARN만)
  │         channels 순회 → channel.State == state 정확 일치
  │         → exclude 키워드(host_name/host_alias/message contains) 체크
  │         → CreatePost (priority 메타데이터 포함, 순차 발송)
  └─ 위치 KVSet("channel_last_processed_position")
```

### 3-2. DM 파이프라인 (개편 범위 외 추정 — 확인 필요)

```
pollingLoopWithLock
  ├─ tb_kko_tran 에서 occr_dt=오늘 AND (timestamp, occr_seq) > lastPos
  ├─ row.recipient_num(전화번호) → 정규화(숫자만) → 3/3~4/4 분해
  ├─ Crowd DB(cb01n310)에서 epno 조회 → username = "m"+epno
  └─ GetDirectChannel(bot, user) → CreatePost
```

### 3-3. 라우팅 설정 모델 (AS-IS)

`notification_channels` (System Console custom, JSON 문자열):

```json
{
  "channel_id": "...", "name": "...",
  "priority": "urgent|important|standard",
  "state": 1,
  "exclude_host_name": "kw1,kw2",
  "exclude_host_alias": "",
  "exclude_message": ""
}
```

- 채널당 state 1개(정확 일치). 한 채널이 state 3과 4를 모두 받으려면 **같은 채널을 2개 항목으로 중복 등록**해야 하는 구조.
- 제외 키워드는 채널 단위 contains 필터 — Control-M 등 소스성 노이즈 차단에 이미 부분적으로 사용 가능한 장치.

## 4. HA / 중복 방지 메커니즘 (AS-IS)

- 두 노드가 **각자 폴링**하고 각자 in-memory position을 유지. row 단위 발송 직전에 KV atomic set-if-absent(TTL 300초)로 선점 — 이긴 노드만 발송.
- position KV는 양 노드가 각자 덮어씀(last-write-wins). 노드 간 position 차이는 row 마킹이 흡수하지만, **한 노드가 5분(TTL) 이상 뒤처지면 재발송 가능성** 존재 (§5-5).
- `tryMarkRowAsProcessed`는 KV 오류 시 `true` 반환 = **fail-open(중복 발송 허용)**. 유실보다 중복을 택한 의도적 설계로 보이나 문서화된 바 없음.

## 5. 기술부채 및 결함 목록

| # | 항목 | 심각도 | 내용 |
|---|---|---|---|
| 5-1 | 크레덴셜 하드코딩 | 위생 (하향) | 하드코딩 값은 테스트용 더미로 확인됨(2026-07-08, 실빌드와 무관). 다만 실계정처럼 보이는 값의 외부 반출은 오해·보안점검 지적 소지가 있어 개편 시 config(secret) 주입 구조로 정리 |
| 5-2 | 비밀번호 로그 노출 | 중간 | `connectUserDB`의 password_hint 로그 — 값이 더미라도 패턴 자체가 부적절, 개편 시 제거 |
| 5-3 | SQL 식별자 문자열 연결 | 중간 | 테이블명/컬럼명을 설정값으로 직접 concat. 관리자 입력이라 실위험은 낮으나 보안 점검 지적 확실 → 식별자 quoting/화이트리스트 필요 |
| 5-4 | 자정 롤오버 알람 누락 | **수용(동결)** | 날짜 변경 시 어제 테이블 잔여분을 건너뛰고 오늘 max로 점프 — 자정 부근 최대 PollInterval분량 미발송 가능. 현행 동작 유지로 결정(2026-07-08), 수정하지 않고 알려진 제약으로 문서화. 일별 테이블은 자정 생성 확인됨 |
| 5-5 | event_id 문자열 비교 | **해소** | 실데이터 확인 결과 event_id는 18자리 zero-padded 고정폭(YYYYMMDDHHMMSS + 초당 시퀀스 4자리) → 사전순 비교 안전. 결함 아님 |
| 5-6 | N+1 쿼리 | 중간 | tick당 목록 쿼리 1회 + row별 `SELECT *` 개별 조회. 100건이면 101쿼리. 단일 쿼리로 통합 가능 |
| 5-7 | 처리량 상한 | 중간 | LIMIT 100 / tick(기본 30초) = **분당 최대 200건**, 발송은 순차 CreatePost. 피크 분당 1,000건 유입 시 백로그 지연 누적(유실은 아님). 개편 시 배치 크기·발송 동시성 재설계 |
| 5-8 | 설정 저장 = 폴링 재시작 | 중간 | 매핑(채널 목록)이 config에 있어 항목 하나 고칠 때마다 DB 재연결·폴링 재기동. 매핑이 수백 row로 커지는 TO-BE에서는 유지 불가 → 매핑을 KV로 분리해야 함 |
| 5-9 | 고루틴 종료 비보장 | 낮음 | `cancelPollingJobs`가 100ms sleep으로만 대기. 재시작 직후 이전 루프의 발송이 겹칠 수 있음(row 마킹이 실질 방어) |
| 5-10 | state==0 무발송 | 낮음 | state 파싱 실패/0이면 WARN 로그 후 폐기 — fallback 채널 부재로 유실. TO-BE의 unmatched 채널 요건과 직결 |
| 5-11 | api 패키지 미연결 | 정보 | `ServeHTTP` 훅이 Plugin에 구현되어 있지 않아 api/ 전체가 데드 코드. 웹훅·관리 API는 이 골격을 살려 신규 연결 |

## 6. 재사용 / 폐기 판단 (개편 관점)

**재사용 가치 높음**: row 선점 마킹 패턴(`tryMarkRowAsProcessed`), 폴링 위치 관리 구조, 봇 생성(`ensureBotUser`), priority 메타데이터 발송, exclude 키워드 필터 개념, DM 파이프라인 전체(불변 유지 시), Makefile/빌드 체인.

**재설계 대상**: 라우팅(state 일치 → source+key 매핑), 매핑 저장소(config → KV), 발송(순차 → bounded 동시성), 메시지 그룹핑(신규: 스레드), 수신(신규: Tmax 웹훅), 관리 UI(재시작 부작용 제거).

**즉시 조치(개편과 무관)**: 없음 — 5-1/5-2는 더미 데이터로 확인되어 개편 내 위생 정리 항목으로 하향(2026-07-08).
